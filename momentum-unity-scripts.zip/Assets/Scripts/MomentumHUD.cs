using UnityEngine;
public class MomentumHUD : MonoBehaviour {
    void OnGUI() {
        var m = MomentumSystem.I; if (m == null) return;
        float w = 360, x = (Screen.width - w) / 2, y = Screen.height - 50;
        GUI.Box(new Rect(x, y, w, 18), "");
        var c = GUI.color; GUI.color = Color.Lerp(Color.gray, Color.magenta, m.Normalized);
        GUI.DrawTexture(new Rect(x, y, w * m.Normalized, 18), Texture2D.whiteTexture); GUI.color = c;
        GUI.Label(new Rect(x, y + 20, w, 24), $"{m.Tier} {Mathf.RoundToInt(m.value)}%  |  SPEED x{m.SpeedMult:0.00}  |  STABILITY {Mathf.RoundToInt(m.Stability * 100)}%  |  CHAIN x{m.Combo}");
    }
}
