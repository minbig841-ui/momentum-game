using UnityEngine;
public class MomentumSystem : MonoBehaviour {
    public static MomentumSystem I;
    [Range(0,100)] public float value = 30f;
    public float standDrain = 24f, slowDrain = 5f, moveDrain = 2f;
    float chainTimer; int combo;
    public float Normalized => value / 100f;
    public float SpeedMult => 1f + 0.9f * Normalized;   // up to ~1.9x
    public float Stability => Normalized;                // 0 = wild, 1 = laser
    public int Combo => combo;
    public string Tier => value < 25 ? "COLD" : value < 55 ? "WARM" : value < 85 ? "HOT" : "OVERDRIVE";
    void Awake() { I = this; }
    // Chained actions inside the window give escalating bonus gain.
    public void Add(float amount) {
        combo = chainTimer > 0 ? combo + 1 : 1; chainTimer = 1.3f;
        value = Mathf.Min(100, value + amount * (1f + 0.15f * Mathf.Min(combo, 6)));
    }
    public void AddContinuous(float perSecond) { value = Mathf.Min(100, value + perSecond * Time.deltaTime); chainTimer = Mathf.Max(chainTimer, .6f); }
    public void Penalty(float amount) { value = Mathf.Max(0, value - amount); }
    public void Drain(bool standingStill, bool slow) {
        float d = standingStill ? standDrain : slow ? slowDrain : moveDrain;
        value = Mathf.Max(0, value - d * Time.deltaTime);
    }
    void Update() { chainTimer = Mathf.Max(0, chainTimer - Time.deltaTime); if (chainTimer <= 0) combo = 0; }
}
