using UnityEngine;
[RequireComponent(typeof(Rigidbody2D))]
public class Bullet : MonoBehaviour {
    public float damage = 1f, life = 1.5f; bool enemy;
    public void Init(Vector2 vel, bool fromEnemy) { enemy = fromEnemy; GetComponent<Rigidbody2D>().linearVelocity = vel; Destroy(gameObject, life); }
    void OnTriggerEnter2D(Collider2D o) {
        if (!enemy && o.TryGetComponent(out Enemy e)) { e.Hit(damage); Destroy(gameObject); }
        else if (enemy && o.TryGetComponent(out PlayerController2D p)) { p.TakeDamage(8f); Destroy(gameObject); }
        else if (!o.isTrigger && o.gameObject.layer != gameObject.layer && !o.TryGetComponent<Enemy>(out _) && !o.TryGetComponent<PlayerController2D>(out _)) Destroy(gameObject);
    }
}
