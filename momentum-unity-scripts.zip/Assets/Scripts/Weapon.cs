using UnityEngine;
public class Weapon : MonoBehaviour {
    public Bullet bulletPrefab; public Transform muzzle;
    public float fireRate = .11f, bulletSpeed = 22f, maxSpreadDeg = 9f, minSpreadDeg = .6f;
    float cd; Camera cam;
    void Start() { cam = Camera.main; }
    void Update() {
        cd -= Time.deltaTime;
        Vector2 aim = (Vector2)cam.ScreenToWorldPoint(Input.mousePosition) - (Vector2)muzzle.position;
        float ang = Mathf.Atan2(aim.y, aim.x) * Mathf.Rad2Deg;
        if (Input.GetMouseButton(0) && cd <= 0) {
            cd = fireRate;
            // Weapon stability comes directly from momentum.
            float spread = Mathf.Lerp(maxSpreadDeg, minSpreadDeg, MomentumSystem.I.Stability);
            float a = (ang + Random.Range(-spread, spread)) * Mathf.Deg2Rad;
            var b = Instantiate(bulletPrefab, muzzle.position, Quaternion.identity);
            b.Init(new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * bulletSpeed, false);
        }
    }
}
