using UnityEngine;
public class Enemy : MonoBehaviour {
    public float hp = 3, speed = 3f, fireEvery = 1.6f, range = 12f; public Bullet bulletPrefab; Transform player; float t;
    void Start() { player = FindFirstObjectByType<PlayerController2D>().transform; }
    void Update() {
        float dx = player.position.x - transform.position.x, ad = Mathf.Abs(dx);
        transform.position += Vector3.right * (ad > 6f ? Mathf.Sign(dx) : ad < 3.5f ? -Mathf.Sign(dx) : 0) * speed * Time.deltaTime;
        t += Time.deltaTime;
        if (t > fireEvery && ad < range) {
            t = 0; Vector2 d = ((Vector2)player.position - (Vector2)transform.position).normalized;
            d = Quaternion.Euler(0, 0, Random.Range(-8f, 8f)) * d;
            Instantiate(bulletPrefab, transform.position, Quaternion.identity).Init(d * 8f, true);
        }
    }
    public void Hit(float d) {
        hp -= d; if (hp > 0) return;
        MomentumSystem.I.Add(14f); player.GetComponent<PlayerController2D>().Heal(4f); Destroy(gameObject);
    }
}
