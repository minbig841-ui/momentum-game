using UnityEngine;
[RequireComponent(typeof(Rigidbody2D), typeof(CapsuleCollider2D))]
public class PlayerController2D : MonoBehaviour {
    public LayerMask groundMask;
    public float baseSpeed = 7f, accel = 60f, jumpForce = 15f, wallJumpX = 9f;
    public float slideSpeedBoost = 1.2f, slideTime = .8f, wallRunFall = -1.5f;
    public float maxHealth = 100f; public float health = 100f;
    Rigidbody2D rb; CapsuleCollider2D col; Vector2 stdSize, stdOffset;
    bool grounded, sliding, wallRunning; int wallDir; float slideT, invuln;
    void Awake() { rb = GetComponent<Rigidbody2D>(); col = GetComponent<CapsuleCollider2D>(); stdSize = col.size; stdOffset = col.offset; rb.freezeRotation = true; health = maxHealth; }
    void Update() {
        var m = MomentumSystem.I; invuln -= Time.deltaTime;
        float dir = Input.GetAxisRaw("Horizontal");
        float maxS = baseSpeed * m.SpeedMult;
        Vector2 v = rb.linearVelocity;
        var b = col.bounds;
        grounded = Physics2D.OverlapBox(new Vector2(b.center.x, b.min.y - .05f), new Vector2(b.size.x * .9f, .1f), 0, groundMask);
        wallDir = Physics2D.Raycast(b.center, Vector2.right, b.extents.x + .1f, groundMask) ? 1 :
                  Physics2D.Raycast(b.center, Vector2.left, b.extents.x + .1f, groundMask) ? -1 : 0;
        bool wantSlide = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.LeftControl);
        // SLIDE
        if (wantSlide && grounded && !sliding && Mathf.Abs(v.x) > 4f) {
            sliding = true; slideT = slideTime; m.Add(7f);
            v.x = Mathf.Sign(v.x) * Mathf.Max(Mathf.Abs(v.x), maxS) * slideSpeedBoost;
            col.size = new Vector2(stdSize.x, stdSize.y * .55f); col.offset = stdOffset - new Vector2(0, stdSize.y * .22f);
        }
        if (sliding) {
            slideT -= Time.deltaTime; v.x *= Mathf.Pow(.55f, Time.deltaTime); m.AddContinuous(6f);
            if (!wantSlide || slideT <= 0 || Mathf.Abs(v.x) < 3f || !grounded) { sliding = false; col.size = stdSize; col.offset = stdOffset; }
        } else v.x = Mathf.MoveTowards(v.x, dir * maxS, accel * Time.deltaTime);
        // WALL-RUN
        bool was = wallRunning; wallRunning = !grounded && wallDir != 0 && dir == wallDir;
        if (wallRunning && !was) m.Add(8f);
        if (wallRunning) { m.AddContinuous(12f); v.y = Mathf.Max(v.y, wallRunFall); }
        // JUMP / WALL-JUMP
        if (Input.GetButtonDown("Jump")) {
            if (grounded) { v.y = jumpForce; if (sliding) { sliding = false; col.size = stdSize; col.offset = stdOffset; v.x *= 1.15f; } }
            else if (wallDir != 0) { v.y = jumpForce * .95f; v.x = -wallDir * (wallJumpX * m.SpeedMult); m.Add(6f); }
        }
        rb.linearVelocity = v;
        m.Drain(grounded && !sliding && Mathf.Abs(v.x) < 1f, Mathf.Abs(v.x) < maxS * .5f);
    }
    public void TakeDamage(float d) { if (invuln > 0) return; invuln = .3f; health -= d; MomentumSystem.I.Penalty(8f); if (health <= 0) UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex); }
    public void Heal(float h) { health = Mathf.Min(maxHealth, health + h); }
}
