# MOMENTUM - Unity 6 (2D) port
Setup (about 5 minutes):
1. Create a new Unity 6 2D project. Copy Assets/Scripts into it.
2. Project Settings > Player > Active Input Handling = Both (scripts use the classic Input API).
3. Create a "Ground" layer. Put your floor, platforms and tall walls on it (Box Collider 2D).
4. Empty object "Game": add MomentumSystem + MomentumHUD.
5. Player: Rigidbody2D (Gravity Scale ~4), CapsuleCollider2D, PlayerController2D (Ground Mask = Ground). Child "Muzzle" + Weapon script.
6. Prefabs: Bullet (Rigidbody2D gravity 0, trigger Collider2D, Bullet script) and Enemy (Collider2D, Enemy script, assign Bullet prefab).
7. Place a few enemies; add a spawner later. Press Play.
